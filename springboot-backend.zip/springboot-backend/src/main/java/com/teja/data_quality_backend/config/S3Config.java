
package com.teja.data_quality_backend.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;

@Configuration
public class S3Config {

    @Bean
    public S3Client s3Client() {

        return S3Client.builder()
                .region(Region.AP_SOUTH_1)
                .credentialsProvider(
                        DefaultCredentialsProvider.create()
                )
                .build();
    }
}
